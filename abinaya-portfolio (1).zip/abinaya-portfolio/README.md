# Abinaya D Portfolio

A single page static website. No build step and no dependencies.

Files
- index.html : the whole website (design, content and script)
- README.md  : these notes

## Put it on GitHub

Option A, in the browser
1. Go to github.com, click New repository, name it abinaya-portfolio, and create it.
2. Click "uploading an existing file", drag in index.html and README.md, and click Commit changes.

Option B, from a terminal inside this folder
```
git init
git add .
git commit -m "Add portfolio website"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/abinaya-portfolio.git
git push -u origin main
```

## Get a link with Vercel
1. Go to vercel.com and sign in with GitHub.
2. Click Add New, then Project, and import the abinaya-portfolio repository.
3. Leave Framework Preset as Other. Leave Build Command and Output Directory empty.
4. Click Deploy. Vercel gives you a link such as abinaya-portfolio.vercel.app.

Every time you change index.html and push to GitHub, Vercel updates the live site automatically.

## Updating content
Open index.html and search for "EDIT HERE" near the top of the script. Projects, services, results, process steps and skills are plain lists. Copy a block to add a new project.

## Making the contact form send email
1. Create a free form at formspree.io (or Web3Forms, EmailJS) and copy its URL.
2. In index.html, set formEndpoint to that URL, for example formEndpoint: "https://formspree.io/f/your-form-id"
3. Commit and push. Messages then arrive in your inbox.

Until formEndpoint is set, the Send Message button opens a ready written email to abinayad2204@gmail.com.
